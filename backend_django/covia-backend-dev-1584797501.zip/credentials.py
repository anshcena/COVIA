SECRET_KEY = 'kq%!g=9@&lzym2j8#4ywce%%^=d!bz%01e1$*f^jfyfgve-xom'


ALLOWED_HOSTS = [
    'localhost',
    'jn271pzbqe.execute-api.us-east-2.amazonaws.com',
    'covia.robomx.tech',
    'covia.robomx.in',
    '4u1i5tiyqb.execute-api.ap-south-1.amazonaws.com',
    'covia-api.robomx.tech'
]

HOST = 'mongodb+srv://robomex:2PDBg4D8AZSE9k8@covia-pvglf.mongodb.net/test?retryWrites=true&w=majority'

DB_PASS = '2PDBg4D8AZSE9k8'
DB_USER = 'robomex'